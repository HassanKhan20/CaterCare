// Mock catercare data — realistic DFW home cooks
window.COOKS = [
  {
    id: "amira",
    name: "Amira Hassan",
    photo: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=800&q=80",
    coverPhoto: "https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?w=1600&q=80",
    cuisines: ["Egyptian", "Levantine"],
    neighborhood: "Plano",
    distanceMiles: 1.2,
    rating: 4.9,
    reviewCount: 142,
    story: "I learned to cook in my grandmother's kitchen in Alexandria. Every dish has a memory — koshari was Sunday lunch, kofta was my father's birthday. I cook the way she taught me: low and slow, with what's in season.",
    yearsCooking: 18,
    badges: ["DSHS registered", "Food handler cert"],
    dishes: [
      { id: "amira-1", name: "Koshari", desc: "Rice, lentils, macaroni, crispy onions, spiced tomato sauce. Cairo's national comfort food.", price: 1400, lead: 4, allergens: ["wheat"], tcs: true, photo: "https://images.unsplash.com/photo-1567620832903-9fc6debc209f?w=800&q=80" },
      { id: "amira-2", name: "Molokhia with chicken", desc: "Jute leaf stew with garlic-coriander tadka, served over rice with poached chicken.", price: 1650, lead: 6, allergens: [], tcs: true, photo: "https://images.unsplash.com/photo-1547592180-85f173990554?w=800&q=80" },
      { id: "amira-3", name: "Beef kofta (4 skewers)", desc: "Hand-minced beef with parsley, onion, and seven-spice. Served with tahini and pita.", price: 1850, lead: 6, allergens: ["sesame", "wheat"], tcs: true, photo: "https://images.unsplash.com/photo-1529042410759-befb1204b468?w=800&q=80" },
      { id: "amira-4", name: "Basbousa", desc: "Semolina cake soaked in rosewater syrup, topped with almonds. Shelf-stable.", price: 800, lead: 4, allergens: ["wheat", "dairy", "nuts"], tcs: false, photo: "https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=800&q=80" }
    ]
  },
  {
    id: "rosa",
    name: "Rosa Mendez",
    photo: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=800&q=80",
    coverPhoto: "https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=1600&q=80",
    cuisines: ["Oaxacan", "Mexican"],
    neighborhood: "Frisco",
    distanceMiles: 2.8,
    rating: 5.0,
    reviewCount: 89,
    story: "My family is from Teotitlán del Valle. The mole on my menu is the same one my mother made for my quinceañera — twenty-three ingredients, toasted on a comal, ground on metate. It takes me two days. It's worth it.",
    yearsCooking: 24,
    badges: ["DSHS registered", "Cottage food certified"],
    dishes: [
      { id: "rosa-1", name: "Mole negro with turkey", desc: "Twenty-three ingredient black mole. Two-day prep. Served with rice and warm corn tortillas.", price: 2200, lead: 24, allergens: ["nuts", "sesame"], tcs: true, photo: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800&q=80" },
      { id: "rosa-2", name: "Tlayuda Oaxaqueña", desc: "Large crisp tortilla, asiento, refried beans, quesillo, avocado, salsa de molcajete.", price: 1650, lead: 4, allergens: ["dairy", "wheat"], tcs: true, photo: "https://images.unsplash.com/photo-1551504734-5ee1c4a1479b?w=800&q=80" },
      { id: "rosa-3", name: "Tamales rojos (dozen)", desc: "Pork shoulder slow-cooked in guajillo-ancho sauce, wrapped in masa and corn husks.", price: 2400, lead: 12, allergens: [], tcs: true, photo: "https://images.unsplash.com/photo-1599974579688-8dbdd335c77f?w=800&q=80" }
    ]
  },
  {
    id: "priya",
    name: "Priya Sharma",
    photo: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=800&q=80",
    coverPhoto: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=1600&q=80",
    cuisines: ["Punjabi", "North Indian"],
    neighborhood: "Plano",
    distanceMiles: 0.6,
    rating: 4.8,
    reviewCount: 211,
    story: "I grew up in Amritsar. My dal makhani simmers for eight hours, the way my mother insists. No shortcuts. The smell tells you it's nearly done.",
    yearsCooking: 15,
    badges: ["DSHS registered", "Food handler cert"],
    dishes: [
      { id: "priya-1", name: "Dal makhani", desc: "Black urad and rajma simmered overnight in cream, butter, and tomato. Served with jeera rice.", price: 1450, lead: 8, allergens: ["dairy"], tcs: true, photo: "https://images.unsplash.com/photo-1626500155103-29736d39dd5d?w=800&q=80" },
      { id: "priya-2", name: "Butter chicken", desc: "Tandoor-style chicken in a smoked tomato-cream gravy. Comes with two butter naan.", price: 1750, lead: 6, allergens: ["dairy", "wheat", "nuts"], tcs: true, photo: "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=800&q=80" },
      { id: "priya-3", name: "Aloo paratha (3 pcs)", desc: "Whole wheat flatbread stuffed with spiced potato. White butter and pickle.", price: 1200, lead: 4, allergens: ["wheat", "dairy"], tcs: true, photo: "https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=800&q=80" },
      { id: "priya-4", name: "Gulab jamun (6 pcs)", desc: "Khoya dumplings in cardamom-saffron syrup. Shelf-stable for 5 days.", price: 850, lead: 4, allergens: ["dairy", "wheat"], tcs: false, photo: "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800&q=80" }
    ]
  },
  {
    id: "linh",
    name: "Linh Nguyen",
    photo: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=800&q=80",
    coverPhoto: "https://images.unsplash.com/photo-1582878826629-29b7ad1cdc43?w=1600&q=80",
    cuisines: ["Vietnamese", "Central Vietnamese"],
    neighborhood: "Garland",
    distanceMiles: 4.1,
    rating: 4.9,
    reviewCount: 156,
    story: "From Huế. My grandmother sold bún bò from a corner shop for forty years. I brought her broth recipe with me when I came to Texas in 2003. It hasn't changed.",
    yearsCooking: 22,
    badges: ["DSHS registered"],
    dishes: [
      { id: "linh-1", name: "Bún bò Huế", desc: "Spicy beef-lemongrass noodle soup. Brisket, pork knuckle, fresh herbs, lime.", price: 1500, lead: 4, allergens: ["fish", "wheat"], tcs: true, photo: "https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=800&q=80" },
      { id: "linh-2", name: "Bánh xèo (2 large)", desc: "Crispy turmeric crepes filled with pork, shrimp, bean sprouts. Lettuce + herbs to wrap.", price: 1350, lead: 4, allergens: ["shellfish", "fish"], tcs: true, photo: "https://images.unsplash.com/photo-1559314809-0d155014e29e?w=800&q=80" },
      { id: "linh-3", name: "Chè ba màu", desc: "Three-color dessert: mung bean, red bean, pandan jelly, coconut cream.", price: 700, lead: 4, allergens: [], tcs: false, photo: "https://images.unsplash.com/photo-1488477181946-6428a0291777?w=800&q=80" }
    ]
  },
  {
    id: "tendai",
    name: "Tendai Mukamuri",
    photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80",
    coverPhoto: "https://images.unsplash.com/photo-1535473895227-bdecb20fb157?w=1600&q=80",
    cuisines: ["Zimbabwean", "Southern African"],
    neighborhood: "Carrollton",
    distanceMiles: 5.3,
    rating: 4.8,
    reviewCount: 47,
    story: "I cook the food of Harare. Sadza with peanut-leaf relish. Slow-stewed beef with okra. Food that tells you exactly where it's from.",
    yearsCooking: 11,
    badges: ["Food handler cert"],
    dishes: [
      { id: "tendai-1", name: "Sadza with nyama & muriwo", desc: "White maize meal, stewed beef, collard greens with peanut butter.", price: 1450, lead: 4, allergens: ["nuts"], tcs: true, photo: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=800&q=80" },
      { id: "tendai-2", name: "Dovi (peanut chicken stew)", desc: "Chicken slow-cooked in tomato and roasted peanut sauce. Served with sadza or rice.", price: 1550, lead: 4, allergens: ["nuts"], tcs: true, photo: "https://images.unsplash.com/photo-1604152135912-04a022e23696?w=800&q=80" },
      { id: "tendai-3", name: "Mukate (sweet fried bread)", desc: "Lightly sweet fried bread. Shelf-stable, 4 pieces.", price: 650, lead: 4, allergens: ["wheat", "dairy"], tcs: false, photo: "https://images.unsplash.com/photo-1509440159596-0249088b5862?w=800&q=80" }
    ]
  },
  {
    id: "kenji",
    name: "Kenji Tanaka",
    photo: "https://images.unsplash.com/photo-1463453091185-61582044d556?w=800&q=80",
    coverPhoto: "https://images.unsplash.com/photo-1580822184713-fc5400e7fe10?w=1600&q=80",
    cuisines: ["Japanese", "Home-style"],
    neighborhood: "Allen",
    distanceMiles: 3.4,
    rating: 4.9,
    reviewCount: 98,
    story: "Osaka home cooking. The kind my mother packed in my bento. Nothing fancy — katsu curry, simmered fish, perfect rice. The ordinary done right.",
    yearsCooking: 9,
    badges: ["DSHS registered", "Food handler cert"],
    dishes: [
      { id: "kenji-1", name: "Katsu curry", desc: "Panko pork cutlet over Japanese curry. Pickles, short-grain rice.", price: 1650, lead: 4, allergens: ["wheat", "egg", "soy"], tcs: true, photo: "https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=800&q=80" },
      { id: "kenji-2", name: "Chirashi bowl", desc: "Sushi rice topped with marinated salmon, tamago, cucumber, ikura.", price: 1850, lead: 4, allergens: ["fish", "egg", "soy"], tcs: true, photo: "https://images.unsplash.com/photo-1553621042-f6e147245754?w=800&q=80" }
    ]
  },
  {
    id: "fatima",
    name: "Fatima Diallo",
    photo: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=800&q=80&sat=-100",
    coverPhoto: "https://images.unsplash.com/photo-1567620832903-9fc6debc209f?w=1600&q=80",
    cuisines: ["Senegalese", "West African"],
    neighborhood: "Dallas",
    distanceMiles: 6.2,
    rating: 4.7,
    reviewCount: 64,
    story: "Dakar, by way of Dallas. Thieboudienne is the dish — broken rice, tomato-stewed fish, root vegetables. The national dish of Senegal. I make it every Sunday.",
    yearsCooking: 14,
    badges: ["DSHS registered"],
    dishes: [
      { id: "fatima-1", name: "Thieboudienne", desc: "Stuffed fish, broken jollof rice, carrots, cassava, tamarind sauce.", price: 1850, lead: 6, allergens: ["fish"], tcs: true, photo: "https://images.unsplash.com/photo-1571197119282-7c4ae2c1cc73?w=800&q=80" },
      { id: "fatima-2", name: "Mafé (peanut beef stew)", desc: "Beef in tomato-peanut gravy with sweet potato and okra. Over rice.", price: 1550, lead: 4, allergens: ["nuts"], tcs: true, photo: "https://images.unsplash.com/photo-1574484284002-952d92456975?w=800&q=80" }
    ]
  },
  {
    id: "eloise",
    name: "Eloise Bernard",
    photo: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=800&q=80",
    coverPhoto: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=1600&q=80",
    cuisines: ["French", "Bistro"],
    neighborhood: "Plano",
    distanceMiles: 1.9,
    rating: 4.9,
    reviewCount: 178,
    story: "I trained in Lyon. Twenty years later I cook for my neighbors out of my Plano kitchen. Cassoulet on Sundays, ratatouille when the tomatoes are good, tarte tatin always.",
    yearsCooking: 28,
    badges: ["DSHS registered", "Food handler cert"],
    dishes: [
      { id: "eloise-1", name: "Cassoulet", desc: "White beans, duck confit, garlic sausage, slow-baked under breadcrumb crust.", price: 2400, lead: 24, allergens: ["wheat"], tcs: true, photo: "https://images.unsplash.com/photo-1547592180-85f173990554?w=800&q=80" },
      { id: "eloise-2", name: "Ratatouille niçoise", desc: "Summer vegetables — eggplant, zucchini, peppers, tomato — slow-cooked separately, layered together.", price: 1650, lead: 6, allergens: [], tcs: true, photo: "https://images.unsplash.com/photo-1572453800999-e8d2d1589b7c?w=800&q=80" },
      { id: "eloise-3", name: "Tarte Tatin", desc: "Caramelized apple upside-down tart, butter pastry. Serves 6.", price: 2200, lead: 8, allergens: ["wheat", "dairy", "egg"], tcs: false, photo: "https://images.unsplash.com/photo-1568571780765-9276ac8b75a2?w=800&q=80" }
    ]
  }
];

window.CUISINES = [
  { id: "all", label: "All" },
  { id: "egyptian", label: "Egyptian" },
  { id: "oaxacan", label: "Oaxacan" },
  { id: "punjabi", label: "Punjabi" },
  { id: "vietnamese", label: "Vietnamese" },
  { id: "japanese", label: "Japanese" },
  { id: "zimbabwean", label: "Zimbabwean" },
  { id: "senegalese", label: "Senegalese" },
  { id: "french", label: "French" }
];

// Flat list of trending dishes
window.TRENDING_DISH_IDS = ["rosa-1", "priya-2", "linh-1", "amira-2", "eloise-1", "kenji-2"];
