/* global React, ReactDOM, TopNav, BrowseScreen, CookScreen, DishSheet, CartDrawer,
   CheckoutSheet, OrderConfirm, OrdersScreen, AccountScreen,
   useTweaks, TweaksPanel, TweakSection, TweakRadio, TweakSelect, TweakColor, TweakToggle */

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "palette": "olive",
  "density": "comfy",
  "displayFont": "sans",
  "bodyFont": "dm-sans"
}/*EDITMODE-END*/;

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [route, setRoute] = useState({ kind: "browse" });
  const [cartOpen, setCartOpen] = useState(false);
  const [dishOpen, setDishOpen] = useState(null);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [confirmCook, setConfirmCook] = useState(null);
  const [cart, setCart] = useState({ cookId: null, cookName: null, items: [] });
  const [location, setLocation] = useState("Plano · 75024");

  // Apply tweaks to root
  useEffect(() => {
    const root = document.documentElement;
    root.dataset.palette = t.palette;
    root.dataset.density = t.density;
    root.dataset.displayFont = t.displayFont;
    root.dataset.bodyFont = t.bodyFont;
  }, [t.palette, t.density, t.displayFont, t.bodyFont]);

  // Nav handler: opens sheets for dishes, routes elsewhere
  const onNav = useCallback((r) => {
    if (r.kind === "dish") {
      setDishOpen(r.id);
      return;
    }
    setRoute(r);
    window.scrollTo({ top: 0, behavior: "instant" });
  }, []);

  const addToCart = useCallback((cook, dish, qty = 1) => {
    setCart(prev => {
      // Same cook? merge or add
      if (prev.cookId && prev.cookId !== cook.id) {
        // for prototype: silently replace cart (real app would confirm)
        return {
          cookId: cook.id,
          cookName: cook.name,
          items: [{ dishId: dish.id, cookId: cook.id, name: dish.name, priceCents: dish.price, qty, photo: dish.photo }]
        };
      }
      const existing = prev.items.find(i => i.dishId === dish.id);
      const items = existing
        ? prev.items.map(i => i.dishId === dish.id ? { ...i, qty: i.qty + qty } : i)
        : [...prev.items, { dishId: dish.id, cookId: cook.id, name: dish.name, priceCents: dish.price, qty, photo: dish.photo }];
      return { cookId: cook.id, cookName: cook.name, items };
    });
    setCartOpen(true);
  }, []);

  const setQty = useCallback((dishId, qty) => {
    setCart(prev => {
      if (qty <= 0) {
        const items = prev.items.filter(i => i.dishId !== dishId);
        return items.length === 0 ? { cookId: null, cookName: null, items: [] } : { ...prev, items };
      }
      return { ...prev, items: prev.items.map(i => i.dishId === dishId ? { ...i, qty } : i) };
    });
  }, []);

  const removeItem = useCallback((dishId) => setQty(dishId, 0), [setQty]);

  const cartCount = cart.items.reduce((s, i) => s + i.qty, 0);

  const handleCheckout = () => {
    setCartOpen(false);
    setCheckoutOpen(true);
  };

  const handlePlaceOrder = () => {
    setConfirmCook(cart.cookName);
    setCart({ cookId: null, cookName: null, items: [] });
    setCheckoutOpen(false);
    setRoute({ kind: "confirm" });
  };

  return (
    <>
      <TopNav
        onCart={() => setCartOpen(true)}
        cartCount={cartCount}
        onNav={onNav}
        route={route}
        onOpenLocation={() => setLocation(location.includes("Plano") ? "Frisco · 75034" : "Plano · 75024")}
        location={location}
      />

      {route.kind === "browse" && <BrowseScreen onNav={onNav} onAddToCart={addToCart} />}
      {route.kind === "cook" && <CookScreen cookId={route.id} onNav={onNav} />}
      {route.kind === "orders" && <OrdersScreen onNav={onNav} />}
      {route.kind === "account" && <AccountScreen />}
      {route.kind === "confirm" && <OrderConfirm onNav={onNav} cookName={confirmCook ?? "Your cook"} />}

      {dishOpen && (
        <DishSheet
          dishId={dishOpen}
          onClose={() => setDishOpen(null)}
          onAdd={addToCart}
          onNavCook={(id) => { setDishOpen(null); onNav({ kind: "cook", id }); }}
        />
      )}

      <CartDrawer
        open={cartOpen}
        onClose={() => setCartOpen(false)}
        cart={cart}
        onSetQty={setQty}
        onRemove={removeItem}
        onNavCook={(id) => { setCartOpen(false); onNav({ kind: "cook", id }); }}
        onCheckout={handleCheckout}
      />

      <CheckoutSheet
        open={checkoutOpen}
        onClose={() => setCheckoutOpen(false)}
        cart={cart}
        onPlace={handlePlaceOrder}
      />

      <TweaksPanel>
        <TweakSection label="Palette" />
        <TweakRadio
          label="Theme"
          value={t.palette}
          options={["olive", "cobalt", "wine", "midnight"]}
          onChange={(v) => setTweak("palette", v)}
        />
        <TweakSection label="Type" />
        <TweakSelect
          label="Display"
          value={t.displayFont}
          options={[
            { value: "sans",      label: "Same as body" },
            { value: "playfair",  label: "Playfair Display" },
            { value: "grotesque", label: "Bricolage Grotesque" },
          ]}
          onChange={(v) => setTweak("displayFont", v)}
        />
        <TweakSelect
          label="Body"
          value={t.bodyFont}
          options={[
            { value: "dm-sans", label: "DM Sans" },
            { value: "manrope", label: "Manrope" },
            { value: "jakarta", label: "Plus Jakarta Sans" },
            { value: "space",   label: "Space Grotesk" },
          ]}
          onChange={(v) => setTweak("bodyFont", v)}
        />
        <TweakSection label="Layout" />
        <TweakRadio
          label="Density"
          value={t.density}
          options={["comfy", "compact"]}
          onChange={(v) => setTweak("density", v)}
        />
      </TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
