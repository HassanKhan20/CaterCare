# Catercare — buyer-flow prototype

Self-contained hi-fi prototype of the buyer-facing experience. Drop this folder
anywhere in the repo (e.g. `prototype/buyer-flow/`) and open `Catercare.html`
directly in a browser — no build step.

## What's in it

- `Catercare.html` — entry, font imports, mount point
- `styles.css` — full design system (palette tokens, type, layout)
- `data.js` — mock cooks + dishes
- `ui.jsx` — primitives (Btn, Chip, Stars, Icon, TopNav, PriceTag)
- `screens.jsx` — Browse, Cook detail, Dish sheet, Cart, Checkout, Confirm, Orders, Account
- `app.jsx` — App shell + routing state + Tweaks config
- `tweaks-panel.jsx` — live design controls (palette / fonts / density)

## Run locally

```bash
# any static server works
python3 -m http.server 8000
# or
npx serve .
```

Then open http://localhost:8000/Catercare.html

## Design notes

- **Type:** humanist sans throughout (DM Sans default, with Manrope / Plus Jakarta Sans / Space Grotesk as tweaks). No italic-serif anywhere decorative.
- **Palette:** four directions exposed via Tweaks — Olive (default), Cobalt, Wine, Midnight.
- **Layout:** asymmetric grid, generous whitespace, 4px corner radius, no gradients.
- **Accent:** single accent color per palette; semantic statuses (ok/warn/danger) reserved for genuine state.

## Porting to the Next.js app

The prototype intentionally uses inline React + Babel so it runs without a build.
When porting:

1. Lift `styles.css` palette tokens into `globals.css` (replace the current dark
   amber tokens).
2. Reuse the type scale and layout primitives.
3. Components map cleanly to the existing `components/ui/` and `components/buyer/`
   folders — `CookCard`, `DishRow`, `CartDrawer`, etc.
