/* global React, COOKS, CUISINES, TRENDING_DISH_IDS, Icon, Stars, Chip, Pill, PriceTag, Btn */

function findCook(id) {return COOKS.find((c) => c.id === id);}
function findDish(id) {
  for (const c of COOKS) {
    const d = c.dishes.find((x) => x.id === id);
    if (d) return { cook: c, dish: d };
  }
  return null;
}

// ===========================================================
// BROWSE
// ===========================================================
function BrowseScreen({ onNav, onAddToCart }) {
  const [cuisine, setCuisine] = useState("all");
  const [sort, setSort] = useState("nearest");

  const filtered = useMemo(() => {
    let cs = [...COOKS];
    if (cuisine !== "all") {
      cs = cs.filter((c) => c.cuisines.some((x) => x.toLowerCase().includes(cuisine)));
    }
    if (sort === "nearest") cs.sort((a, b) => a.distanceMiles - b.distanceMiles);
    if (sort === "rated") cs.sort((a, b) => b.rating - a.rating);
    if (sort === "popular") cs.sort((a, b) => b.reviewCount - a.reviewCount);
    return cs;
  }, [cuisine, sort]);

  const featured = filtered[0] ?? COOKS[0];
  const rest = filtered.slice(1);
  const trending = TRENDING_DISH_IDS.map((id) => findDish(id)).filter(Boolean);

  return (
    <main className="cc-page">
      {/* Editorial hero */}
      <section className="cc-hero">
        <div className="cc-hero-meta">
          <span className="cc-tag">Plano · Frisco · Allen · Dallas</span>
          <span className="cc-tag-dot">Thursday, May 14</span>
        </div>
        <h1 className="cc-hero-title">
          Dinner from the kitchen down the street.
        </h1>
        <div className="cc-hero-foot">
          <p className="cc-hero-desc">
            38 home cooks within ten miles of you. Licensed kitchens, fair pay,
            food made by someone you could actually meet.
          </p>
          <div className="cc-hero-stats">
            <Stat label="Cooks near you" value="38" />
            <Stat label="Avg fee vs. apps" value="−18%" tone="accent" />
            <Stat label="Cook payout" value="88¢/$1" />
          </div>
        </div>
      </section>

      {/* Cuisine filter strip */}
      <section className="cc-strip">
        <div className="cc-strip-inner">
          <div className="cc-chips">
            {CUISINES.map((c) =>
            <Chip key={c.id} active={cuisine === c.id} onClick={() => setCuisine(c.id)}>{c.label}</Chip>
            )}
          </div>
          <div className="cc-sort">
            <Icon name="sort" size={14} />
            <select value={sort} onChange={(e) => setSort(e.target.value)}>
              <option value="nearest">Nearest first</option>
              <option value="rated">Highest rated</option>
              <option value="popular">Most reviewed</option>
            </select>
          </div>
        </div>
      </section>

      {/* Featured cook — editorial split */}
      <section className="cc-featured" onClick={() => onNav({ kind: "cook", id: featured.id })}>
        <div className="cc-featured-img">
          <img src={featured.coverPhoto} alt={featured.name} />
          <div className="cc-featured-overlay">
            <span className="cc-tag cc-tag-light">This week's pick</span>
          </div>
        </div>
        <div className="cc-featured-body">
          <div className="cc-featured-eyebrow">
            <span>{featured.cuisines.join(" · ")}</span>
            <span>·</span>
            <span>{featured.distanceMiles.toFixed(1)} mi</span>
          </div>
          <h2 className="cc-featured-name">{featured.name}</h2>
          <p className="cc-featured-story">"{featured.story}"</p>
          <div className="cc-featured-meta">
            <div className="cc-meta-block">
              <span className="cc-meta-num">{featured.rating}</span>
              <span className="cc-meta-cap">{featured.reviewCount} reviews</span>
            </div>
            <div className="cc-meta-block">
              <span className="cc-meta-num">{featured.dishes.length}</span>
              <span className="cc-meta-cap">on the menu</span>
            </div>
            <div className="cc-meta-block">
              <span className="cc-meta-num">{featured.yearsCooking}<span className="cc-meta-suf">y</span></span>
              <span className="cc-meta-cap">cooking</span>
            </div>
          </div>
          <Btn variant="primary" size="lg" iconAfter="arrow-right" onClick={(e) => {e.stopPropagation();onNav({ kind: "cook", id: featured.id });}}>
            See the menu
          </Btn>
        </div>
      </section>

      {/* All cooks */}
      <section className="cc-section">
        <header className="cc-section-head">
          <div>
            <h3 className="cc-section-title">All cooks near you</h3>
            <p className="cc-section-sub">{filtered.length} approved within 10 miles</p>
          </div>
          <a className="cc-link" href="#">Map view <Icon name="arrow-right" size={13} /></a>
        </header>
        <div className="cc-grid">
          {rest.map((c, i) =>
          <CookCard key={c.id} cook={c} variant={i === 0 ? "wide" : "default"} onClick={() => onNav({ kind: "cook", id: c.id })} />
          )}
        </div>
      </section>

      {/* Trending dishes carousel */}
      <section className="cc-section">
        <header className="cc-section-head">
          <div>
            <h3 className="cc-section-title">On the menu this week</h3>
            <p className="cc-section-sub">Dishes neighbors are ordering most</p>
          </div>
        </header>
        <div className="cc-rail">
          {trending.map(({ cook, dish }) =>
          <DishMiniCard key={dish.id} cook={cook} dish={dish} onClick={() => onNav({ kind: "dish", id: dish.id })} />
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="cc-footer">
        <div className="cc-footer-inner">
          <div>
            <div className="cc-logo cc-logo-static">
              <span className="cc-logo-mark">
                <svg viewBox="0 0 32 32" width="22" height="22"><circle cx="16" cy="16" r="14" fill="none" stroke="currentColor" strokeWidth="2.4" /><path d="M9 16c2-3 5-3 7 0s5 3 7 0" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" /></svg>
              </span>
              <span className="cc-logo-text">catercare</span>
            </div>
            <p className="cc-footer-tag">Hyperlocal home food, DFW.<br />Built under Texas SB 541.</p>
          </div>
          <FooterCol title="Eat" links={["Browse cooks", "Cuisines", "Gift cards", "Subscriptions"]} />
          <FooterCol title="Cook with us" links={["Apply to cook", "Cook handbook", "DSHS guide", "Fee structure"]} />
          <FooterCol title="Deliver" links={["Become a driver", "Driver app", "Background check"]} />
          <FooterCol title="Catercare" links={["About", "Press", "Contact", "Terms", "Privacy"]} />
        </div>
        <div className="cc-footer-bottom">
          <span>© 2026 Catercare, Inc.</span>
          <span className="cc-mono">10–12% cook commission · 8–10% buyer fee · 100% of tips to drivers</span>
        </div>
      </footer>
    </main>);

}

function Stat({ label, value, tone }) {
  return (
    <div className="cc-stat" data-tone={tone}>
      <div className="cc-stat-val">{value}</div>
      <div className="cc-stat-lab">{label}</div>
    </div>);

}

function FooterCol({ title, links }) {
  return (
    <div className="cc-footer-col">
      <h4>{title}</h4>
      <ul>{links.map((l) => <li key={l}><a href="#">{l}</a></li>)}</ul>
    </div>);

}

// Cook card — two variants: default and "wide" (spans 2 cols, image left)
function CookCard({ cook, onClick, variant = "default" }) {
  const [liked, setLiked] = useState(false);
  if (variant === "wide") {
    return (
      <article className="cc-card cc-card-wide" onClick={onClick}>
        <div className="cc-card-img">
          <img src={cook.coverPhoto} alt={cook.name} />
          <button type="button" className="cc-fav" onClick={(e) => {e.stopPropagation();setLiked(!liked);}} aria-label="Save">
            <Icon name={liked ? "heart-fill" : "heart"} size={16} />
          </button>
        </div>
        <div className="cc-card-body">
          <div className="cc-card-eye">
            <span>{cook.cuisines.join(" · ")}</span>
            <span>·</span>
            <span>{cook.distanceMiles.toFixed(1)} mi · {cook.neighborhood}</span>
          </div>
          <h4 className="cc-card-name">{cook.name}</h4>
          <p className="cc-card-story">"{cook.story.split(".")[0]}."</p>
          <div className="cc-card-foot">
            <div className="cc-card-rate"><Stars value={cook.rating} size={13} /> <span className="cc-mono">{cook.rating} · {cook.reviewCount}</span></div>
            <span className="cc-card-dishes">{cook.dishes.length} dishes →</span>
          </div>
        </div>
      </article>);

  }
  return (
    <article className="cc-card" onClick={onClick}>
      <div className="cc-card-img">
        <img src={cook.coverPhoto} alt={cook.name} />
        <button type="button" className="cc-fav" onClick={(e) => {e.stopPropagation();setLiked(!liked);}} aria-label="Save">
          <Icon name={liked ? "heart-fill" : "heart"} size={16} />
        </button>
        <div className="cc-card-distance"><Icon name="pin" size={11} /> {cook.distanceMiles.toFixed(1)} mi</div>
      </div>
      <div className="cc-card-body">
        <div className="cc-card-eye">{cook.cuisines.join(" · ")}</div>
        <h4 className="cc-card-name">{cook.name}</h4>
        <div className="cc-card-foot">
          <div className="cc-card-rate"><Stars value={cook.rating} size={12} /><span className="cc-mono">{cook.rating}</span></div>
          <span className="cc-card-dishes">{cook.dishes.length} dishes</span>
        </div>
      </div>
    </article>);

}

function DishMiniCard({ cook, dish, onClick }) {
  return (
    <article className="cc-dish-mini" onClick={onClick}>
      <div className="cc-dish-mini-img">
        <img src={dish.photo} alt={dish.name} />
      </div>
      <div className="cc-dish-mini-body">
        <div className="cc-dish-mini-eye">{cook.name} · {cook.neighborhood}</div>
        <h5>{dish.name}</h5>
        <div className="cc-dish-mini-foot">
          <PriceTag cents={dish.price} />
          <span className="cc-mono">{dish.lead}h lead</span>
        </div>
      </div>
    </article>);

}

// ===========================================================
// COOK DETAIL
// ===========================================================
function CookScreen({ cookId, onNav }) {
  const cook = findCook(cookId);
  const [active, setActive] = useState("menu");
  if (!cook) return null;

  return (
    <main className="cc-page">
      <button type="button" className="cc-back" onClick={() => onNav({ kind: "browse" })}>
        <Icon name="arrow-left" size={14} /> All cooks
      </button>

      {/* Cook header — editorial split */}
      <section className="cc-cook-head">
        <div className="cc-cook-head-text">
          <div className="cc-eye">{cook.cuisines.join(" · ")} · {cook.neighborhood}</div>
          <h1 className="cc-cook-name">{cook.name}</h1>
          <div className="cc-cook-meta">
            <span><Stars value={cook.rating} size={14} /> <strong>{cook.rating}</strong> <span className="cc-muted">({cook.reviewCount} reviews)</span></span>
            <span className="cc-dot">·</span>
            <span><Icon name="pin" size={13} /> {cook.distanceMiles.toFixed(1)} mi</span>
            <span className="cc-dot">·</span>
            <span><Icon name="clock" size={13} /> {cook.yearsCooking} years cooking</span>
          </div>
          <p className="cc-cook-story">"{cook.story}"</p>
          <div className="cc-cook-badges">
            {cook.badges.map((b) =>
            <span key={b} className="cc-badge"><Icon name="shield" size={13} /> {b}</span>
            )}
          </div>
        </div>
        <div className="cc-cook-head-img">
          <img src={cook.coverPhoto} alt={cook.name} />
          <div className="cc-cook-portrait">
            <img src={cook.photo} alt={cook.name} />
          </div>
        </div>
      </section>

      {/* Tabs */}
      <div className="cc-tabs">
        <button type="button" onClick={() => setActive("menu")} className={active === "menu" ? "is-on" : ""}>Menu <span className="cc-mono">({cook.dishes.length})</span></button>
        <button type="button" onClick={() => setActive("about")} className={active === "about" ? "is-on" : ""}>About</button>
        <button type="button" onClick={() => setActive("schedule")} className={active === "schedule" ? "is-on" : ""}>Schedule</button>
      </div>

      {active === "menu" &&
      <section className="cc-menu">
          {cook.dishes.map((d) =>
        <DishRow key={d.id} dish={d} onClick={() => onNav({ kind: "dish", id: d.id })} />
        )}
        </section>
      }
      {active === "about" &&
      <section className="cc-about">
          <div className="cc-about-grid">
            <div>
              <h3>The kitchen</h3>
              <p>{cook.name} cooks out of a home kitchen in {cook.neighborhood}, TX. All food is prepared the day of pickup. {cook.cuisines.join(", ")} dishes.</p>
            </div>
            <div>
              <h3>Compliance</h3>
              <ul className="cc-list">
                {cook.badges.map((b) => <li key={b}><Icon name="check" size={14} /> {b}</li>)}
                <li><Icon name="check" size={14} /> Texas SB 541 cottage food operator</li>
                <li><Icon name="check" size={14} /> Background check on file</li>
              </ul>
            </div>
            <div>
              <h3>Allergens & notes</h3>
              <p className="cc-muted">Each dish lists its allergens individually. This is a home kitchen — cross-contact with nuts, dairy, gluten, and shellfish is possible.</p>
            </div>
          </div>
        </section>
      }
      {active === "schedule" &&
      <section className="cc-schedule">
          <div className="cc-sched-grid">
            {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((d, i) => {
            const open = i !== 1 && i !== 6;
            return (
              <div key={d} className={`cc-sched-day ${open ? "is-open" : "is-closed"}`}>
                  <div className="cc-sched-name">{d}</div>
                  <div className="cc-sched-time">{open ? "11:00 – 19:30" : "Closed"}</div>
                </div>);

          })}
          </div>
          <p className="cc-muted cc-sched-note"><Icon name="clock" size={13} /> 4–24 hour notice on most dishes. Order by 6pm for next-day pickup.</p>
        </section>
      }
    </main>);

}

function DishRow({ dish, onClick }) {
  return (
    <article className="cc-dish-row" onClick={onClick}>
      <div className="cc-dish-row-body">
        <div className="cc-dish-row-head">
          <h4>{dish.name}</h4>
          <PriceTag cents={dish.price} />
        </div>
        <p>{dish.desc}</p>
        <div className="cc-dish-row-meta">
          <span className="cc-mono"><Icon name="clock" size={12} /> {dish.lead}h lead</span>
          {dish.tcs && <span className="cc-mono cc-tag-mini">DSHS · TCS</span>}
          {!dish.tcs && <span className="cc-mono cc-tag-mini">Shelf-stable</span>}
          {dish.allergens.length > 0 && <span className="cc-allergens">contains {dish.allergens.join(", ")}</span>}
        </div>
      </div>
      <div className="cc-dish-row-img">
        <img src={dish.photo} alt={dish.name} />
      </div>
    </article>);

}

// ===========================================================
// DISH DETAIL (sheet)
// ===========================================================
function DishSheet({ dishId, onClose, onAdd, onNavCook }) {
  const result = findDish(dishId);
  const [qty, setQty] = useState(1);
  if (!result) return null;
  const { cook, dish } = result;

  return (
    <div className="cc-sheet-wrap" onClick={onClose}>
      <div className="cc-sheet cc-sheet-dish" onClick={(e) => e.stopPropagation()}>
        <button type="button" className="cc-sheet-close" onClick={onClose}><Icon name="close" size={18} /></button>
        <div className="cc-dish-photo">
          <img src={dish.photo} alt={dish.name} />
        </div>
        <div className="cc-dish-body">
          <button type="button" className="cc-dish-cookline" onClick={() => onNavCook(cook.id)}>
            <span className="cc-dish-cook-avatar"><img src={cook.photo} alt="" /></span>
            <span>By <strong>{cook.name}</strong> · {cook.neighborhood}</span>
            <Icon name="arrow-right" size={13} />
          </button>
          <h2>{dish.name}</h2>
          <p className="cc-dish-desc">{dish.desc}</p>

          <dl className="cc-detail-list">
            <DetailRow label="Lead time" value={`${dish.lead} hours notice`} />
            <DetailRow label="Category" value={dish.tcs ? "Prepared meal (TCS) · DSHS registered" : "Shelf-stable (non-TCS)"} />
            <DetailRow label="Allergens" value={dish.allergens.length ? dish.allergens.join(", ") : "None disclosed"} />
            <DetailRow label="Portion" value="1 serving" />
          </dl>

          <div className="cc-dish-cta">
            <div className="cc-qty">
              <button type="button" onClick={() => setQty(Math.max(1, qty - 1))} aria-label="Decrease"><Icon name="minus" size={14} /></button>
              <span>{qty}</span>
              <button type="button" onClick={() => setQty(qty + 1)} aria-label="Increase"><Icon name="plus" size={14} /></button>
            </div>
            <Btn variant="primary" size="lg" full onClick={() => {onAdd(cook, dish, qty);onClose();}}>
              Add to cart · <PriceTag cents={dish.price * qty} />
            </Btn>
          </div>
        </div>
      </div>
    </div>);

}

function DetailRow({ label, value }) {
  return (
    <div className="cc-detail-row">
      <dt>{label}</dt>
      <dd>{value}</dd>
    </div>);

}

// ===========================================================
// CART
// ===========================================================
function CartDrawer({ open, onClose, cart, onSetQty, onRemove, onNavCook, onCheckout }) {
  const subtotal = cart.items.reduce((s, i) => s + i.priceCents * i.qty, 0);
  const serviceFee = Math.round(subtotal * 0.09);
  const delivery = subtotal > 0 ? 449 : 0;
  const tip = Math.round(delivery * 1.0); // suggestion
  const total = subtotal + serviceFee + delivery + tip;

  return (
    <div className={`cc-drawer-wrap ${open ? "is-open" : ""}`} onClick={onClose}>
      <aside className="cc-drawer" onClick={(e) => e.stopPropagation()}>
        <header className="cc-drawer-head">
          <h3>Your basket {cart.cookName && <span className="cc-mono">· {cart.cookName}</span>}</h3>
          <button type="button" onClick={onClose} aria-label="Close"><Icon name="close" size={18} /></button>
        </header>

        {cart.items.length === 0 ?
        <div className="cc-empty">
            <div className="cc-empty-art"><StripeFill /></div>
            <h4>Nothing here yet.</h4>
            <p>Tap a dish on a cook's menu to add it.</p>
          </div> :

        <>
            <div className="cc-drawer-items">
              {cart.items.map((it) =>
            <div key={it.dishId} className="cc-cart-item">
                  <div className="cc-cart-img"><img src={it.photo} alt={it.name} /></div>
                  <div className="cc-cart-body">
                    <h5>{it.name}</h5>
                    <div className="cc-cart-meta cc-mono">$ {(it.priceCents / 100).toFixed(2)} each</div>
                    <div className="cc-cart-controls">
                      <div className="cc-qty cc-qty-sm">
                        <button type="button" onClick={() => onSetQty(it.dishId, it.qty - 1)}><Icon name="minus" size={12} /></button>
                        <span>{it.qty}</span>
                        <button type="button" onClick={() => onSetQty(it.dishId, it.qty + 1)}><Icon name="plus" size={12} /></button>
                      </div>
                      <button type="button" className="cc-cart-remove" onClick={() => onRemove(it.dishId)}>Remove</button>
                    </div>
                  </div>
                  <div className="cc-cart-price"><PriceTag cents={it.priceCents * it.qty} /></div>
                </div>
            )}
            </div>

            <div className="cc-drawer-foot">
              <div className="cc-totals">
                <TotalLine label="Subtotal" value={subtotal} />
                <TotalLine label="Service fee (9%)" value={serviceFee} sub="vs. ~30% on apps" />
                <TotalLine label="Delivery" value={delivery} />
                <TotalLine label="Driver tip" value={tip} sub="100% to driver" />
                <div className="cc-total-divider" />
                <TotalLine label="Total" value={total} large />
              </div>
              <p className="cc-disclosure">
                <Icon name="shield" size={13} /> Home-kitchen disclosure: this food is prepared in a private home licensed under Texas SB&nbsp;541.
              </p>
              <Btn variant="primary" size="lg" full iconAfter="arrow-right" onClick={onCheckout}>
                Checkout · <PriceTag cents={total} />
              </Btn>
            </div>
          </>
        }
      </aside>
    </div>);

}

function TotalLine({ label, value, sub, large }) {
  return (
    <div className={`cc-total-line ${large ? "is-large" : ""}`}>
      <div className="cc-total-label">
        {label}
        {sub && <span className="cc-total-sub">{sub}</span>}
      </div>
      <div className="cc-total-val cc-mono">${(value / 100).toFixed(2)}</div>
    </div>);

}

// ===========================================================
// CHECKOUT (lightweight modal — pickup time + payment summary)
// ===========================================================
function CheckoutSheet({ open, onClose, cart, onPlace }) {
  const [time, setTime] = useState("today-1830");
  const [address] = useState("4321 Preston Rd, Plano TX 75024");
  const [card] = useState("•••• 4242");
  const [accepted, setAccepted] = useState(false);
  if (!open) return null;

  const subtotal = cart.items.reduce((s, i) => s + i.priceCents * i.qty, 0);
  const serviceFee = Math.round(subtotal * 0.09);
  const delivery = 449;
  const tip = 449;
  const total = subtotal + serviceFee + delivery + tip;

  return (
    <div className="cc-sheet-wrap" onClick={onClose}>
      <div className="cc-sheet cc-sheet-checkout" onClick={(e) => e.stopPropagation()}>
        <button type="button" className="cc-sheet-close" onClick={onClose}><Icon name="close" size={18} /></button>
        <header className="cc-co-head">
          <span className="cc-eye">Final step</span>
          <h2>Confirm your order</h2>
        </header>

        <div className="cc-co-grid">
          <div className="cc-co-section">
            <h4>Deliver to</h4>
            <div className="cc-co-row"><Icon name="pin" size={15} /> <span>{address}</span> <button type="button" className="cc-link-sm">Change</button></div>
          </div>

          <div className="cc-co-section">
            <h4>When</h4>
            <div className="cc-co-times">
              {[
              { id: "today-1830", t: "Today, 6:30 pm", note: "fastest · 1h 20m" },
              { id: "today-1930", t: "Today, 7:30 pm", note: "2h 20m" },
              { id: "tom-1230", t: "Tomorrow, 12:30 pm", note: "lunch" }].
              map((o) =>
              <button type="button" key={o.id}
              onClick={() => setTime(o.id)}
              className={`cc-co-time ${time === o.id ? "is-on" : ""}`}>
                  <span className="cc-co-time-t">{o.t}</span>
                  <span className="cc-co-time-n">{o.note}</span>
                </button>
              )}
            </div>
          </div>

          <div className="cc-co-section">
            <h4>Pay with</h4>
            <div className="cc-co-row"><Icon name="shield" size={15} /> <span>Visa {card}</span> <button type="button" className="cc-link-sm">Change</button></div>
          </div>
        </div>

        <div className="cc-co-totals">
          <TotalLine label="Subtotal" value={subtotal} />
          <TotalLine label="Service fee" value={serviceFee} sub="9% — vs. ~30% on apps" />
          <TotalLine label="Delivery" value={delivery} />
          <TotalLine label="Driver tip" value={tip} />
          <div className="cc-total-divider" />
          <TotalLine label="Total" value={total} large />
        </div>

        <label className="cc-disclosure-box">
          <input type="checkbox" checked={accepted} onChange={(e) => setAccepted(e.target.checked)} />
          <span><strong>Home-kitchen disclosure.</strong> I understand this food is prepared in a private home licensed under Texas SB&nbsp;541 — not in a commercial restaurant kitchen.</span>
        </label>

        <Btn variant="primary" size="lg" full iconAfter="arrow-right" disabled={!accepted} onClick={onPlace}>
          Place order · <PriceTag cents={total} />
        </Btn>
      </div>
    </div>);

}

// ===========================================================
// CONFIRMATION
// ===========================================================
function OrderConfirm({ onNav, cookName }) {
  return (
    <div className="cc-confirm">
      <div className="cc-confirm-mark">
        <svg viewBox="0 0 64 64" width="64" height="64"><circle cx="32" cy="32" r="29" fill="none" stroke="currentColor" strokeWidth="2" /><path d="m20 32 8 8 16-18" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" /></svg>
      </div>
      <span className="cc-eye">Order #C-2426-019</span>
      <h2>{cookName} is preparing your food.</h2>
      <p>We'll let you know when a driver claims the pickup. Your home cook gets 88¢ of every dollar — thank you for ordering local.</p>
      <Btn variant="primary" size="lg" onClick={() => onNav({ kind: "browse" })}>Back to browse</Btn>
    </div>);

}

// ===========================================================
// SIMPLE ORDERS / ACCOUNT SCREENS (just enough to be navigable)
// ===========================================================
function OrdersScreen({ onNav }) {
  const orders = [
  { id: "C-2426-019", cook: "Amira Hassan", state: "PREPARING", total: 3420, when: "Today · 6:30 pm" },
  { id: "C-2418-201", cook: "Priya Sharma", state: "DELIVERED", total: 2980, when: "May 9 · 7:15 pm" },
  { id: "C-2410-118", cook: "Rosa Mendez", state: "DELIVERED", total: 4450, when: "May 2 · 1:00 pm" }];

  const stateMap = {
    PREPARING: { label: "Preparing", tone: "warn" },
    DELIVERED: { label: "Delivered", tone: "ok" }
  };
  return (
    <main className="cc-page cc-page-narrow">
      <h1 className="cc-page-title">Your orders</h1>
      <p className="cc-page-sub">3 orders · 2 cooks · $109.50 spent this month</p>
      <div className="cc-orders">
        {orders.map((o) =>
        <article key={o.id} className="cc-order">
            <div>
              <div className="cc-mono cc-muted">#{o.id} · {o.when}</div>
              <h4>{o.cook}</h4>
              <span className={`cc-state cc-state-${stateMap[o.state].tone}`}>{stateMap[o.state].label}</span>
            </div>
            <div className="cc-order-right">
              <PriceTag cents={o.total} />
              <button type="button" className="cc-link-sm">View →</button>
            </div>
          </article>
        )}
      </div>
    </main>);

}

function AccountScreen() {
  return (
    <main className="cc-page cc-page-narrow">
      <h1 className="cc-page-title">Account</h1>
      <p className="cc-page-sub">aliyah.r@gmail.com · joined March 2026</p>
      <div className="cc-account-grid">
        {[
        { h: "Addresses", body: "1 saved · Home (default)" },
        { h: "Payment methods", body: "Visa •••• 4242" },
        { h: "Dietary notes", body: "No nuts. Vegetarian-friendly preferred." },
        { h: "Notifications", body: "Order updates · weekly digest" }].
        map((s) =>
        <article key={s.h} className="cc-acc-card">
            <h4>{s.h}</h4>
            <p>{s.body}</p>
            <button type="button" className="cc-link-sm">Manage →</button>
          </article>
        )}
      </div>
    </main>);

}

Object.assign(window, {
  BrowseScreen, CookScreen, DishSheet, CartDrawer, CheckoutSheet,
  OrderConfirm, OrdersScreen, AccountScreen
});