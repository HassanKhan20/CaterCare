/* global React */
const { useState, useEffect, useRef, useMemo, useCallback } = React;

// ---------- Icons (custom inline; no third-party packs) ----------
function Icon({ name, size = 18, stroke = 1.6, className }) {
  const props = {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: stroke,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    className
  };
  switch (name) {
    case "search": return <svg {...props}><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></svg>;
    case "pin": return <svg {...props}><path d="M12 21s-7-6.2-7-11a7 7 0 1 1 14 0c0 4.8-7 11-7 11Z" /><circle cx="12" cy="10" r="2.5" /></svg>;
    case "bag": return <svg {...props}><path d="M5 8h14l-1 12H6L5 8Z" /><path d="M9 8V6a3 3 0 0 1 6 0v2" /></svg>;
    case "arrow-right": return <svg {...props}><path d="M5 12h14" /><path d="m13 6 6 6-6 6" /></svg>;
    case "arrow-left": return <svg {...props}><path d="M19 12H5" /><path d="m11 18-6-6 6-6" /></svg>;
    case "plus": return <svg {...props}><path d="M12 5v14M5 12h14" /></svg>;
    case "minus": return <svg {...props}><path d="M5 12h14" /></svg>;
    case "close": return <svg {...props}><path d="M6 6l12 12M18 6l-6 6-6 6" /></svg>;
    case "star": return <svg {...props} fill="currentColor" stroke="none"><path d="M12 2.5l2.9 6.1 6.6.6-5 4.6 1.5 6.7L12 17.3 5.9 20.5l1.5-6.7-5-4.6 6.6-.6L12 2.5Z" /></svg>;
    case "check": return <svg {...props}><path d="m5 12 4 4 10-10" /></svg>;
    case "shield": return <svg {...props}><path d="M12 3l8 3v5c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6l8-3Z" /><path d="m9 12 2 2 4-4" /></svg>;
    case "clock": return <svg {...props}><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></svg>;
    case "sort": return <svg {...props}><path d="M3 6h13M3 12h9M3 18h5" /><path d="m18 14 3 3-3 3" /><path d="M21 17h-9" /></svg>;
    case "filter": return <svg {...props}><path d="M3 5h18M6 12h12M10 19h4" /></svg>;
    case "leaf": return <svg {...props}><path d="M11 20A7 7 0 0 1 4 13c0-5 5-9 13-9 0 8-4 13-9 13a7 7 0 0 1-3-1" /><path d="M4 20s4-7 9-9" /></svg>;
    case "fire": return <svg {...props}><path d="M12 3c2 4 5 5 5 9a5 5 0 1 1-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-3 0-5 1-8Z" /></svg>;
    case "heart": return <svg {...props}><path d="M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.5-7 10-7 10Z" /></svg>;
    case "heart-fill": return <svg {...props} fill="currentColor" stroke="currentColor"><path d="M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.5-7 10-7 10Z" /></svg>;
    default: return null;
  }
}

// ---------- Tiny primitives ----------
function Stars({ value = 5, size = 12 }) {
  return (
    <span className="cc-stars" style={{ "--star-size": `${size}px` }}>
      {[1,2,3,4,5].map(i => (
        <span key={i} className={i <= Math.round(value) ? "on" : "off"}>
          <Icon name="star" size={size} />
        </span>
      ))}
    </span>
  );
}

function Chip({ children, active, onClick, tone = "neutral" }) {
  return (
    <button type="button" onClick={onClick}
      className={`cc-chip cc-chip-${tone} ${active ? "is-active" : ""}`}>
      {children}
    </button>
  );
}

function Pill({ icon, children, onClick }) {
  return (
    <button type="button" onClick={onClick} className="cc-pill">
      {icon && <Icon name={icon} size={15} />}
      <span>{children}</span>
    </button>
  );
}

function PriceTag({ cents, large }) {
  const dollars = (cents / 100).toFixed(2);
  return (
    <span className={`cc-price ${large ? "cc-price-lg" : ""}`}>
      <span className="cc-price-sym">$</span>{dollars}
    </span>
  );
}

// Subtly-striped SVG used when we want to make a "photo placeholder" feel intentional
function StripeFill({ tone = "warm" }) {
  return (
    <svg width="100%" height="100%" preserveAspectRatio="none" className="cc-stripes" data-tone={tone}>
      <defs>
        <pattern id="cc-stripes-pat" x="0" y="0" width="14" height="14" patternUnits="userSpaceOnUse" patternTransform="rotate(38)">
          <line x1="0" y1="0" x2="0" y2="14" strokeWidth="6" />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#cc-stripes-pat)" />
    </svg>
  );
}

// ---------- Top nav ----------
function TopNav({ onCart, cartCount, onNav, route, onOpenLocation, location }) {
  return (
    <header className="cc-nav">
      <div className="cc-nav-inner">
        <button type="button" className="cc-logo" onClick={() => onNav({ kind: "browse" })}>
          <span className="cc-logo-mark">
            <svg viewBox="0 0 32 32" width="22" height="22"><circle cx="16" cy="16" r="14" fill="none" stroke="currentColor" strokeWidth="2.4"/><path d="M9 16c2-3 5-3 7 0s5 3 7 0" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round"/></svg>
          </span>
          <span className="cc-logo-text">catercare</span>
        </button>
        <button type="button" className="cc-loc" onClick={onOpenLocation}>
          <Icon name="pin" size={15} />
          <span className="cc-loc-label">Deliver to</span>
          <span className="cc-loc-place">{location}</span>
          <span className="cc-loc-caret">▾</span>
        </button>
        <div className="cc-nav-spacer" />
        <nav className="cc-nav-links">
          <button type="button" onClick={() => onNav({ kind: "browse" })} className={route.kind === "browse" ? "is-on" : ""}>Browse</button>
          <button type="button" onClick={() => onNav({ kind: "orders" })} className={route.kind === "orders" ? "is-on" : ""}>Orders</button>
          <button type="button" onClick={() => onNav({ kind: "account" })} className={route.kind === "account" ? "is-on" : ""}>Account</button>
        </nav>
        <button type="button" className="cc-bag-btn" onClick={onCart} aria-label="Cart">
          <Icon name="bag" size={18} />
          {cartCount > 0 && <span className="cc-bag-count">{cartCount}</span>}
        </button>
      </div>
    </header>
  );
}

// ---------- Buttons ----------
function Btn({ children, variant = "primary", size = "md", icon, iconAfter, full, ...rest }) {
  const cls = `cc-btn cc-btn-${variant} cc-btn-${size} ${full ? "cc-btn-full" : ""}`;
  return (
    <button type="button" {...rest} className={cls + " " + (rest.className ?? "")}>
      {icon && <Icon name={icon} size={size === "lg" ? 18 : 15} />}
      <span>{children}</span>
      {iconAfter && <Icon name={iconAfter} size={size === "lg" ? 18 : 15} />}
    </button>
  );
}

// ---------- Helpers exported to window ----------
Object.assign(window, { Icon, Stars, Chip, Pill, PriceTag, StripeFill, TopNav, Btn });
